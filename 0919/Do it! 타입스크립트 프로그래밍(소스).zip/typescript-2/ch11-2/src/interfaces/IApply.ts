import {IFunctor} from './IFunctor'

export interface IApply<T> extends IFunctor<T> {
  ap<U>(b: U)
}