import { range } from './range'

let numbers: number[] = range(1, 10)
console.log(numbers) // [1, 2, 3, 4, 5, 6, 7, 8, 9]
