const numbers2: number[] = [1, 2, 3, 4, 5]
for (let index = 0; index < numbers2.length; index++) {
  const item: number = numbers2[index]
  console.log(item) // 1 2 3 4 5
}
