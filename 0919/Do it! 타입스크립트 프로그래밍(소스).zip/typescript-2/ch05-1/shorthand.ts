let numbers = [1, 2, 3]
let strings = ['Hello', 'World']
console.log(numbers, strings) // [ 1, 2, 3 ] [ 'Hello', 'World' ]
