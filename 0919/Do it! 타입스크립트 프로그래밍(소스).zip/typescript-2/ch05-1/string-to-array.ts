let str = "hello"
let array = str.split("") 
console.log(array) // [ 'h', 'e', 'l', 'l', 'o' ]

let toStr = array.join("")
console.log(toStr) // hello
