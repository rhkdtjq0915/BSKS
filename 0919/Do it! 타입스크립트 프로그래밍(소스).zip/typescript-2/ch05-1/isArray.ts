let a = [1, 2, 3]
let o = { name: 'Jack', age: 32 }
console.log(Array.isArray(a), Array.isArray(o)) // true false
