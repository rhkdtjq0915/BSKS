export type ResultType = [boolean, string]
