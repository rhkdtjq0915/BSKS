export interface IValuable<T> {
  getOrElse(defaultValue: T)
}