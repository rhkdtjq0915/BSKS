export type nullable = undefined | null
export const nullable: nullable = undefined