import * as R from 'ramda'

console.log(
  R.trim(" \t hello \n") // hello
)
