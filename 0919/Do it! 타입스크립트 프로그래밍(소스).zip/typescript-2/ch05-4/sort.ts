// const someArray = [5, 3, 9, 7]
// const shallowCopiedArray = someArray.sort()
// console.log(someArray, shallowCopiedArray) // [ 3, 5, 7, 9 ] [ 3, 5, 7, 9 ]