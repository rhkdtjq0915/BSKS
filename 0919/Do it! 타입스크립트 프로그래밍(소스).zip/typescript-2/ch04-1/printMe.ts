function printMe(name: string, age?: number): void {
  console.log(`name: ${name}, age: ${age}`)
}
