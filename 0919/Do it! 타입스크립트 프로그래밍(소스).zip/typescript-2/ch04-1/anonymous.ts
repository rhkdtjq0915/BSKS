let value = (function(a, b) {
  return a + b
})(1, 2)
console.log(value)
