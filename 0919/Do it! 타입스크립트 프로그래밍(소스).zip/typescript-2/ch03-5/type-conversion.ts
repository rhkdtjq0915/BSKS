let person: object = { name: 'Jack', age: 32 }
;(<{ name: string }>person).name
