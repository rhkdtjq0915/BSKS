let sum = 0
for (let val = 1; val <= 100; ) sum += val++
console.log(sum) // 5050
