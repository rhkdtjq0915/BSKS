import {range} from './range'
for(let value of range(1, 3 + 1))
  console.log(value) // 1 2 3