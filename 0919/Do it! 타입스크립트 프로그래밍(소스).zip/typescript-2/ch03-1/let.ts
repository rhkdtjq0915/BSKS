let n: number = 1
let b: boolean = true // 혹은 false
let s: string = 'hello'
let o: object = {}
