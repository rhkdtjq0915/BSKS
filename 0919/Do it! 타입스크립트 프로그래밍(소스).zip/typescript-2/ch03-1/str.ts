let count = 10,
  message = 'Your count'
let result = `${message} is ${count}`
console.log(result)
