import {inc} from './first-order-func'
console.log(
  inc(1) // 2
)