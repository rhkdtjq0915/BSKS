import {add3} from './third-order-func'
console.log(
  add3(1)(2)(3) // 6
)