export interface IPerson {
  name: string
  age: number
}

export interface ICompany {
  name: string
  age: number
}
