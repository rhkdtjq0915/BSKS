let add2 = function(a, b) {
  return a + b
}
console.log(add2(1, 2)) //3
