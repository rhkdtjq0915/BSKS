let f = function(a, b) { return a + b; }
f = function(a, b) { return a - b; }